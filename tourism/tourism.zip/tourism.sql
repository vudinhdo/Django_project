-- --------------------------------------------------------
-- Máy chủ:                      127.0.0.1
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Phiên bản:           12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping data for table tourism.account_emailaddress: ~0 rows (approximately)
DELETE FROM `account_emailaddress`;

-- Dumping data for table tourism.account_emailconfirmation: ~0 rows (approximately)
DELETE FROM `account_emailconfirmation`;

-- Dumping data for table tourism.apps_author: ~1 rows (approximately)
DELETE FROM `apps_author`;
INSERT INTO `apps_author` (`id`, `name`, `title`, `birth_date`, `address`, `phoneNumber`, `user_id`, `avatar`) VALUES
	(1, 'Vũ Đình Đô', 'a', '2002-09-24', 'Yên Trị', '0779346698', 1, 'static/images/profiles');

-- Dumping data for table tourism.apps_blogs: ~1 rows (approximately)
DELETE FROM `apps_blogs`;
INSERT INTO `apps_blogs` (`id`, `name`, `avatar`, `firstImage`, `secondImage`, `thirdImage`, `description`, `create_at`, `city_blog_id`) VALUES
	(1, 'Nhật Bản: Tokyo - Núi Phú Sĩ - Odaiba - Oshino Hakkai - Kamikochi - Shirakawa- Takayama - Obara - Korankei - Nagoya | Ngắm hoa anh đào mùa thu | Thu bên nhau', 'static/images/image_blogs/phusi1_4LJzMrv.jpg', 'static/images/image_blogs/phusi2_P9dz3AI.jpg', 'static/images/image_blogs/phusi3_4ubW1fs.jpg', 'static/images/image_blogs/phusi4_XtFqQfm.jpg', 'Khoảng tử 200.000 đến 300.000 người leo lên Núi Phú Sĩ  vào mỗi mùa hè. Leo đỉnh núi thường phổ biến nhất vào lúc bình minh - những người leo núi thường bắt đầu leo từ ngày hôm trước và nghỉ qua đêm tại một khu vực nghỉ ngơi trên núi, trước khi khởi hành sớm vào sáng hôm sau để kịp ngắm mặt trời nhô lên khỏi đường chân trời. Trong thời tiền hiện đại, Núi Phú Sĩ  là một nơi khổ luyện cho các shugenja, những người hành trì Shugendo - một tín ngưỡng thờ núi cổ xưa, và ngay cả các tầng lớp thấp hơn cũng đã hành hương đến đây. Vô số đền thờ dưới chân núi là một minh chứng cho ý nghĩa lịch sử và tâm linh của Núi Phú Sĩ.', '2023-10-17 23:23:21.000000', 27);

-- Dumping data for table tourism.apps_booktour: ~0 rows (approximately)
DELETE FROM `apps_booktour`;

-- Dumping data for table tourism.apps_city: ~25 rows (approximately)
DELETE FROM `apps_city`;
INSERT INTO `apps_city` (`id`, `address`, `description`) VALUES
	(1, 'tp-HCM', 'mot vi lanh tu vi dai'),
	(2, 'Ninh Bình', 'quê ny mừn'),
	(3, 'Tay Bac', 'xa'),
	(4, 'An Giang', '1'),
	(5, 'Bà Rịa-Vũng Tàu', '2'),
	(6, 'Bạc Liêu', '3'),
	(7, 'Bắc Giang', '4'),
	(8, 'Bắc Kạn', '11111'),
	(9, 'Bắc Ninh', '111'),
	(10, 'Bến Tre', '1111'),
	(11, 'Bình Dương', '1234'),
	(12, 'Nam Định', '18 nha ae'),
	(13, 'Nghệ An', 'mình là dấn Nghệ Án'),
	(14, 'Thanh Hóa', 'quê nyc của bạn a1 quê Vĩnh Phúc nè'),
	(15, 'Hòa Bình', 'nhà có mấy quả đồi chơi chơi'),
	(16, 'Hải Phòng', 'cho vay tiền đi Hưng'),
	(17, 'Hà Nội', 'làm ơn bớt đơ pls'),
	(18, 'Hưng Yên', 'cho vay tiền đi Trang'),
	(19, 'Tuyên Quang', 'đạp xe là một hệ tư tưởng k nên sử dụng, ở đây chỉ chơi xe máy'),
	(20, 'Vĩnh Long', 'không chơi game'),
	(21, 'Vĩnh Phúc', 'haizzz Bảo có nhớ nyc k'),
	(22, 'Thái Bình', 'gần nhà Sơn Tùng k Vũ ơi'),
	(23, 'Sơn La', 'djtme mấy con lười làm cùng'),
	(24, 'Quảng Bình', 'hát một câu nghe phát'),
	(25, 'Hà Nội - Sapa - Fansipan - Yên Tử - Hạ Long - Ninh Bình - Tràng An - Bái Đính', ',,,,,,,,'),
	(26, 'Hàn Quốc', 'dragonnnn'),
	(27, 'Núi Phú Sĩ - Hàn Quốc', 'phusi-korean');

-- Dumping data for table tourism.apps_comments: ~4 rows (approximately)
DELETE FROM `apps_comments`;
INSERT INTO `apps_comments` (`id`, `body_comment`, `date_comment`, `blog_id`, `user_comment_id`) VALUES
	(1, 'đẹp nha', '2023-10-18 00:15:49.000000', 1, 3),
	(2, 'cũng dc', '2023-10-18 00:16:09.000000', 1, 1),
	(3, 'hello', '2023-10-18 00:16:17.000000', 1, 2),
	(4, 'ok', '2023-10-19 10:18:56.000000', NULL, NULL),
	(5, 'a', '2023-10-19 12:34:57.067559', 1, 3),
	(6, 'asdddd', '2023-10-19 12:36:07.500231', 1, 3);

-- Dumping data for table tourism.apps_customer: ~0 rows (approximately)
DELETE FROM `apps_customer`;

-- Dumping data for table tourism.apps_hotel: ~0 rows (approximately)
DELETE FROM `apps_hotel`;

-- Dumping data for table tourism.apps_tour: ~3 rows (approximately)
DELETE FROM `apps_tour`;
INSERT INTO `apps_tour` (`id`, `name`, `slug`, `tourCode`, `avatar`, `firstImage`, `secondImage`, `thirdImage`, `price`, `starDay`, `endDate`, `maxQuantity`, `remaining`, `destination_id`, `startingGate_id`) VALUES
	(1, 'Sapa - Fansipan - Hà Nội - Yên Tử - Hạ Long - Ninh Bình - Tràng An - Bái Đính', 'sfhnhntb', 'NDSGN186-010-071023VN-V', 'static/images/avatar_tour/ninhbinh1.jpg', 'static/images/avatar_tour/ninhbinh2.jpg', 'static/images/avatar_tour/ninhbinh3.jpg', 'static/images/avatar_tour/ninhbinh4.jpg', 103900, '2023-10-05', '2023-10-26', 10, 10, 2, 1),
	(2, 'Tây Bắc: Hà Nội - Nghĩa Lộ - Tú Lệ - Mù Cang Chải - Sapa - Fansipan - Lai Châu - Điện Biên - Sơn La - Mộc Châu Island', 'tb', 'NDSGN1731-126-091023VU-V', 'static/images/avatar_tour/taybac1.jpg', 'static/images/avatar_tour/taybac2.jpg', 'static/images/avatar_tour/taybac3.jpg', 'static/images/avatar_tour/taybac4.jpg', 103900, '2023-10-05', '2023-10-13', 10, 10, 3, 1),
	(3, 'Hà Nội - Sapa - Fansipan - Yên Tử - Hạ Long - Ninh Bình - Tràng An - Bái Đính', 'hn1', 'NDSGN1861-009-101023VU-V', 'static/images/avatar_tour/baidinh1.jpg', 'static/images/avatar_tour/baidinh2.jpg', 'static/images/avatar_tour/baidinh3.jpg', 'static/images/avatar_tour/baidinh4.jpg', 969000, '2023-10-05', '2023-10-12', 10, 10, 25, 1),
	(4, 'Hàn Quốc: Seoul - Công viên Lotte World - Thủy Cung Lotte Aquarium - Đảo Nami | Trải nghiệm mặc Hanbok & làm kim chi | Thu bên nhau', 'hq', 'NNSGN524-049-121023VN-D', 'static/images/avatar_tour/tq1.jpg', 'static/images/avatar_tour/tq1_QbJBu2p.jpg', 'static/images/avatar_tour/tq1_efU5cOT.jpg', 'static/images/avatar_tour/tq1_8BS49XK.jpg', 15390000, '2023-10-06', '2023-10-12', 12, 5, 26, 1);

-- Dumping data for table tourism.auth_group: ~0 rows (approximately)
DELETE FROM `auth_group`;

-- Dumping data for table tourism.auth_group_permissions: ~0 rows (approximately)
DELETE FROM `auth_group_permissions`;

-- Dumping data for table tourism.auth_permission: ~74 rows (approximately)
DELETE FROM `auth_permission`;
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
	(1, 'Can add log entry', 1, 'add_logentry'),
	(2, 'Can change log entry', 1, 'change_logentry'),
	(3, 'Can delete log entry', 1, 'delete_logentry'),
	(4, 'Can view log entry', 1, 'view_logentry'),
	(5, 'Can add permission', 2, 'add_permission'),
	(6, 'Can change permission', 2, 'change_permission'),
	(7, 'Can delete permission', 2, 'delete_permission'),
	(8, 'Can view permission', 2, 'view_permission'),
	(9, 'Can add group', 3, 'add_group'),
	(10, 'Can change group', 3, 'change_group'),
	(11, 'Can delete group', 3, 'delete_group'),
	(12, 'Can view group', 3, 'view_group'),
	(13, 'Can add user', 4, 'add_user'),
	(14, 'Can change user', 4, 'change_user'),
	(15, 'Can delete user', 4, 'delete_user'),
	(16, 'Can view user', 4, 'view_user'),
	(17, 'Can add content type', 5, 'add_contenttype'),
	(18, 'Can change content type', 5, 'change_contenttype'),
	(19, 'Can delete content type', 5, 'delete_contenttype'),
	(20, 'Can view content type', 5, 'view_contenttype'),
	(21, 'Can add session', 6, 'add_session'),
	(22, 'Can change session', 6, 'change_session'),
	(23, 'Can delete session', 6, 'delete_session'),
	(24, 'Can view session', 6, 'view_session'),
	(25, 'Can add city', 7, 'add_city'),
	(26, 'Can change city', 7, 'change_city'),
	(27, 'Can delete city', 7, 'delete_city'),
	(28, 'Can view city', 7, 'view_city'),
	(29, 'Can add tour', 8, 'add_tour'),
	(30, 'Can change tour', 8, 'change_tour'),
	(31, 'Can delete tour', 8, 'delete_tour'),
	(32, 'Can view tour', 8, 'view_tour'),
	(33, 'Can add hotel', 9, 'add_hotel'),
	(34, 'Can change hotel', 9, 'change_hotel'),
	(35, 'Can delete hotel', 9, 'delete_hotel'),
	(36, 'Can view hotel', 9, 'view_hotel'),
	(37, 'Can add customer', 10, 'add_customer'),
	(38, 'Can change customer', 10, 'change_customer'),
	(39, 'Can delete customer', 10, 'delete_customer'),
	(40, 'Can view customer', 10, 'view_customer'),
	(41, 'Can add book tour', 11, 'add_booktour'),
	(42, 'Can change book tour', 11, 'change_booktour'),
	(43, 'Can delete book tour', 11, 'delete_booktour'),
	(44, 'Can view book tour', 11, 'view_booktour'),
	(45, 'Can add email address', 12, 'add_emailaddress'),
	(46, 'Can change email address', 12, 'change_emailaddress'),
	(47, 'Can delete email address', 12, 'delete_emailaddress'),
	(48, 'Can view email address', 12, 'view_emailaddress'),
	(49, 'Can add email confirmation', 13, 'add_emailconfirmation'),
	(50, 'Can change email confirmation', 13, 'change_emailconfirmation'),
	(51, 'Can delete email confirmation', 13, 'delete_emailconfirmation'),
	(52, 'Can view email confirmation', 13, 'view_emailconfirmation'),
	(53, 'Can add social account', 14, 'add_socialaccount'),
	(54, 'Can change social account', 14, 'change_socialaccount'),
	(55, 'Can delete social account', 14, 'delete_socialaccount'),
	(56, 'Can view social account', 14, 'view_socialaccount'),
	(57, 'Can add social application', 15, 'add_socialapp'),
	(58, 'Can change social application', 15, 'change_socialapp'),
	(59, 'Can delete social application', 15, 'delete_socialapp'),
	(60, 'Can view social application', 15, 'view_socialapp'),
	(61, 'Can add social application token', 16, 'add_socialtoken'),
	(62, 'Can change social application token', 16, 'change_socialtoken'),
	(63, 'Can delete social application token', 16, 'delete_socialtoken'),
	(64, 'Can view social application token', 16, 'view_socialtoken'),
	(65, 'Can add author', 17, 'add_author'),
	(66, 'Can change author', 17, 'change_author'),
	(67, 'Can delete author', 17, 'delete_author'),
	(68, 'Can view author', 17, 'view_author'),
	(69, 'Can add blogs', 18, 'add_blogs'),
	(70, 'Can change blogs', 18, 'change_blogs'),
	(71, 'Can delete blogs', 18, 'delete_blogs'),
	(72, 'Can view blogs', 18, 'view_blogs'),
	(73, 'Can add comments', 19, 'add_comments'),
	(74, 'Can change comments', 19, 'change_comments'),
	(75, 'Can delete comments', 19, 'delete_comments'),
	(76, 'Can view comments', 19, 'view_comments');

-- Dumping data for table tourism.auth_user: ~4 rows (approximately)
DELETE FROM `auth_user`;
INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
	(1, 'pbkdf2_sha256$600000$89YiBa3nLXGTosocDXernl$u/vppZV4+xO04iNtiSciCGZyvNHk81uShMP7sQMjt5U=', '2023-10-19 02:59:51.284118', 1, 'admin', '', '', 'vudinhdo2409@gmail.com', 1, 1, '2023-10-06 16:41:39.718673'),
	(2, 'pbkdf2_sha256$600000$qMxLcAIO6YceUq0dWknjrL$IzG1tBmuS5f0sJ+99R5Yj7UP2QKceqZEsETg9GsBLZE=', NULL, 0, 'phong1210', '', '', '', 0, 1, '2023-10-17 15:46:35.565247'),
	(3, 'pbkdf2_sha256$600000$u4r1bLXC6T4KrziRhpNdcP$hoQXLqgulJaMQmQ6uH2OO+PWqGNdet4NLPk8CcSp8XI=', '2023-10-19 03:44:51.951722', 0, 'do2409', '', '', '', 0, 1, '2023-10-17 15:51:56.935141'),
	(4, 'pbkdf2_sha256$600000$bHt2kCQdtGwkSSshCtGx13$cQw7TS2BliMA7MYWQFGQPEJlu9LbSofmOdr6Rdel1L0=', NULL, 0, 'nhanvat2', '', '', 'admin123456@gmail.com', 0, 1, '2023-10-18 15:20:25.705314');

-- Dumping data for table tourism.auth_user_groups: ~0 rows (approximately)
DELETE FROM `auth_user_groups`;

-- Dumping data for table tourism.auth_user_user_permissions: ~0 rows (approximately)
DELETE FROM `auth_user_user_permissions`;

-- Dumping data for table tourism.django_admin_log: ~9 rows (approximately)
DELETE FROM `django_admin_log`;
INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
	(1, '2023-10-06 17:14:19.379927', '26', 'Hàn Quốc', 1, '[{"added": {}}]', 7, 1),
	(2, '2023-10-06 17:14:30.534271', '4', 'Hàn Quốc: Seoul - Công viên Lotte World - Thủy Cung Lotte Aquarium - Đảo Nami | Trải nghiệm mặc Hanbok & làm kim chi | Thu bên nhau', 1, '[{"added": {}}]', 8, 1),
	(3, '2023-10-17 15:30:52.915810', '1', 'Author object (1)', 1, '[{"added": {}}]', 17, 1),
	(4, '2023-10-17 15:33:55.715400', '1', 'Vũ Đình Đô', 2, '[{"changed": {"fields": ["User"]}}]', 17, 1),
	(5, '2023-10-17 15:46:35.845309', '2', 'phong1210', 1, '[{"added": {}}]', 4, 1),
	(6, '2023-10-17 15:51:57.215204', '3', 'do2409', 1, '[{"added": {}}]', 4, 1),
	(7, '2023-10-17 17:14:40.412502', '27', 'Núi Phú Sĩ - Hàn Quốc', 1, '[{"added": {}}]', 7, 1),
	(8, '2023-10-17 17:15:29.679620', '1', 'Nhật Bản: Tokyo - Núi Phú Sĩ - Odaiba - Oshino Hakkai - Kamikochi - Shirakawa- Takayama - Obara - Korankei - Nagoya | Ngắm hoa anh đào mùa thu | Thu bên nhau - Núi Phú Sĩ - Hàn Quốc - 2023-10-17 23:23', 1, '[{"added": {}}]', 18, 1),
	(9, '2023-10-17 17:16:04.893790', '1', 'Nhật Bản: Tokyo - Núi Phú Sĩ - Odaiba - Oshino Hakkai - Kamikochi - Shirakawa- Takayama - Obara - Korankei - Nagoya | Ngắm hoa anh đào mùa thu | Thu bên nhau - Núi Phú Sĩ - Hàn Quốc - 2023-10-17 23:23', 1, '[{"added": {}}]', 19, 1),
	(10, '2023-10-17 17:16:16.083850', '2', 'Nhật Bản: Tokyo - Núi Phú Sĩ - Odaiba - Oshino Hakkai - Kamikochi - Shirakawa- Takayama - Obara - Korankei - Nagoya | Ngắm hoa anh đào mùa thu | Thu bên nhau - Núi Phú Sĩ - Hàn Quốc - 2023-10-17 23:23', 1, '[{"added": {}}]', 19, 1),
	(11, '2023-10-17 17:16:23.885559', '3', 'Nhật Bản: Tokyo - Núi Phú Sĩ - Odaiba - Oshino Hakkai - Kamikochi - Shirakawa- Takayama - Obara - Korankei - Nagoya | Ngắm hoa anh đào mùa thu | Thu bên nhau - Núi Phú Sĩ - Hàn Quốc - 2023-10-17 23:23', 1, '[{"added": {}}]', 19, 1);

-- Dumping data for table tourism.django_content_type: ~19 rows (approximately)
DELETE FROM `django_content_type`;
INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
	(12, 'account', 'emailaddress'),
	(13, 'account', 'emailconfirmation'),
	(1, 'admin', 'logentry'),
	(17, 'apps', 'author'),
	(18, 'apps', 'blogs'),
	(11, 'apps', 'booktour'),
	(7, 'apps', 'city'),
	(19, 'apps', 'comments'),
	(10, 'apps', 'customer'),
	(9, 'apps', 'hotel'),
	(8, 'apps', 'tour'),
	(3, 'auth', 'group'),
	(2, 'auth', 'permission'),
	(4, 'auth', 'user'),
	(5, 'contenttypes', 'contenttype'),
	(6, 'sessions', 'session'),
	(14, 'socialaccount', 'socialaccount'),
	(15, 'socialaccount', 'socialapp'),
	(16, 'socialaccount', 'socialtoken');

-- Dumping data for table tourism.django_migrations: ~29 rows (approximately)
DELETE FROM `django_migrations`;
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
	(1, 'contenttypes', '0001_initial', '2023-10-06 16:38:59.895525'),
	(2, 'auth', '0001_initial', '2023-10-06 16:39:00.755710'),
	(3, 'account', '0001_initial', '2023-10-06 16:39:01.041632'),
	(4, 'account', '0002_email_max_length', '2023-10-06 16:39:01.074919'),
	(5, 'account', '0003_alter_emailaddress_create_unique_verified_email', '2023-10-06 16:39:01.111928'),
	(6, 'account', '0004_alter_emailaddress_drop_unique_email', '2023-10-06 16:39:01.165940'),
	(7, 'account', '0005_emailaddress_idx_upper_email', '2023-10-06 16:39:01.203949'),
	(8, 'admin', '0001_initial', '2023-10-06 16:39:01.365986'),
	(9, 'admin', '0002_logentry_remove_auto_add', '2023-10-06 16:39:01.375988'),
	(10, 'admin', '0003_logentry_add_action_flag_choices', '2023-10-06 16:39:01.391991'),
	(11, 'apps', '0001_initial', '2023-10-06 16:39:01.938417'),
	(12, 'contenttypes', '0002_remove_content_type_name', '2023-10-06 16:39:02.031439'),
	(13, 'auth', '0002_alter_permission_name_max_length', '2023-10-06 16:39:02.092393'),
	(14, 'auth', '0003_alter_user_email_max_length', '2023-10-06 16:39:02.132264'),
	(15, 'auth', '0004_alter_user_username_opts', '2023-10-06 16:39:02.148270'),
	(16, 'auth', '0005_alter_user_last_login_null', '2023-10-06 16:39:02.227284'),
	(17, 'auth', '0006_require_contenttypes_0002', '2023-10-06 16:39:02.233286'),
	(18, 'auth', '0007_alter_validators_add_error_messages', '2023-10-06 16:39:02.245293'),
	(19, 'auth', '0008_alter_user_username_max_length', '2023-10-06 16:39:02.332242'),
	(20, 'auth', '0009_alter_user_last_name_max_length', '2023-10-06 16:39:02.405264'),
	(21, 'auth', '0010_alter_group_name_max_length', '2023-10-06 16:39:02.436272'),
	(22, 'auth', '0011_update_proxy_permissions', '2023-10-06 16:39:02.454276'),
	(23, 'auth', '0012_alter_user_first_name_max_length', '2023-10-06 16:39:02.524070'),
	(24, 'sessions', '0001_initial', '2023-10-06 16:39:02.574095'),
	(25, 'socialaccount', '0001_initial', '2023-10-06 16:39:02.872057'),
	(26, 'socialaccount', '0002_token_max_lengths', '2023-10-06 16:39:02.930075'),
	(27, 'socialaccount', '0003_extra_data_default_dict', '2023-10-06 16:39:02.941930'),
	(28, 'socialaccount', '0004_app_provider_id_settings', '2023-10-06 16:39:03.072136'),
	(29, 'socialaccount', '0005_socialtoken_nullable_app', '2023-10-06 16:39:03.230176'),
	(30, 'apps', '0002_author', '2023-10-17 15:28:47.155807'),
	(31, 'apps', '0003_author_user', '2023-10-17 15:33:37.806187'),
	(32, 'apps', '0004_blogs_comments', '2023-10-17 16:22:07.529631'),
	(33, 'apps', '0005_alter_comments_date_comment', '2023-10-17 16:22:37.148735'),
	(34, 'apps', '0006_author_avatar', '2023-10-18 15:26:52.851993');

-- Dumping data for table tourism.django_session: ~2 rows (approximately)
DELETE FROM `django_session`;
INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
	('eeeq1qcu62ceva2bdovwcvylwnk7q9cp', '.eJxVjEEOwiAQRe_C2hAoAoNL9z0DGWZQqgaS0q6Md7dNutDtf-_9t4i4LiWuPc9xYnERWpx-t4T0zHUH_MB6b5JaXeYpyV2RB-1ybJxf18P9OyjYy1Yr0JaZHCg7BBeMRXBGQTiHpAlCzplusGGLmqxnr1GR8sk4IssJBvH5AsMtN4Y:1qt7qq:dlxzkCySB4mizVmxXuxGMVhfo8Vjx3NbPoD2LTuKYGk', '2023-11-01 14:48:48.294633'),
	('wb2oexwvcqvn0ag5p2ze11agc0ok6kz7', '.eJxVjjkOwjAUBe_iGln2x05iSnrOEP0tJCy2lKVC3B0spYD2zWj0XqbHbR37bdG5n8SczNEcfjdCvmuuQG6Yr8Vyyes8ka2K3eliL0X0cd7dv8CIy1izBA0MybGLHjVSiIBBByQJxImCR_bQIjbQppQ4MseuFc_SiNNO4ButuYxPrV8KBJfM-wOecj5z:1qtJxr:HcicSp7H-WUnuEVt2sVBO18Tfif_r6z0E3-WN9Ve1Y8', '2023-11-02 03:44:51.956328');

-- Dumping data for table tourism.socialaccount_socialaccount: ~0 rows (approximately)
DELETE FROM `socialaccount_socialaccount`;

-- Dumping data for table tourism.socialaccount_socialapp: ~0 rows (approximately)
DELETE FROM `socialaccount_socialapp`;

-- Dumping data for table tourism.socialaccount_socialtoken: ~0 rows (approximately)
DELETE FROM `socialaccount_socialtoken`;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
